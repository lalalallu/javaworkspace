-- SELECT *
-- FROM person
-- WHERE Sex='男'

CREATE VIEW view_pay(Year,month,No,Name,Sex,professor,DeptName,Base,Bonus,Deduct,Fact)
AS  
    SELECT Year,month,person.No,Name,Sex,professor,DeptName,Base,Bonus,Deduct,Fact
    FROM person,pay,dept
    WHERE person.[No]=pay.[No] AND person.DeptNo=dept.DeptNo



-- CREATE VIEW view_person(NO,Name,sex,professor,DeptNo)
-- AS  
--     SELECT NO,Name,sex,professor,DeptNo
--     FROM person
    

-- SELECT person.Name,base,bonus,deduct,fact,YEAR
-- FROM person,pay,dept
-- WHERE dept.DeptNo=person.DeptNo AND person.[No]=pay.[No] 
-- AND dept.DeptName='市场部' AND [Year]='2005' AND [Month]='1'
go

