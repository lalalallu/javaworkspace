-- CREATE TRIGGER person_del
-- ON person 
-- FOR DELETE
-- AS IF @@ROWCOUNT=0
--         RETURN
--     DELETE pay
--     FROM pay t,deleted d
--     WHERE t.[No]=d.[No]
-- RETURN

-- CREATE TRIGGER person_upd
-- ON person 
-- after UPDATE
-- AS 
--  IF UPDATE(no)
--     UPDATE pay
--     SET pay.[No]=(select [No] from inserted )
--     WHERE no=(select [No] from deleted)
-- RETURN
 

CREATE TRIGGER pay_update
ON pay
FOR UPDATE
AS
    DECLARE @num_rows INT
    SELECT @num_rows=@@ROWCOUNT
    IF @num_rows=0
        RETURN
    IF(select count(*)
       FROM person p,inserted i
       WHERE p.no=i.no)!=@num_rows
    BEGIN 
        RAISERROR('试图修改非法的员工工号到pay表中！',16,1)
        ROLLBACK TRANSACTION
        RETURN
    END
RETURN

-- UPDATE person 
-- SET No='000005'
-- WHERE no='5'

-- CREATE TRIGGER pay_insert
-- ON pay
-- FOR INSERT
-- AS  
--     IF NOT EXISTS(select no FROM person WHERE no in (select no from inserted))
--     BEGIN 
--         RAISERROR('no person!!',16,1)
--         ROLLBACK TRANSACTION
--         RETURN
--     END
-- RETURN
    
-- INSERT 
-- into pay
-- VALUES('10','2005','5','100','100','20')

-- DROP TRIGGER pay_insert

-- CREATE TYPE d_no FROM CHAR(2) NOT NULL
-- GO
-- CREATE TABLE dept1
-- (
--     DeptNo d_no not null unique,
--  	DeptName d_no not null
-- )

-- CREATE FUNCTION fun_checkno(@pno CHAR(6))
--  RETURNS INTEGER AS
--  BEGIN 
--     DECLARE @num INT
--     IF Exists (select no from person WHERE no=@pno)
--         SELECT @num=0
--     ELSE
--         SELECT @num=-1
--     RETURN @num
-- END

-- DECLARE @num INT
-- SELECT @num=dbo.fun_checkno('000008')
-- IF @num=0
--     INSERT pay VALUES('000008',2005,2,2200,280,12.4)

-- CREATE PROC pro_calage @code CHAR(6) ,@age INT OUTPUT
-- AS 
--     DECLARE @birth int ,@today int 
--     SELECT @birth=YEAR(birthday)
--         FROM person
--         WHERE no=@code
--     SELECT @today=YEAR(GETDATE())
--     SELECT @age=@today-@birth

-- DECLARE @age INT
-- EXEC pro_calage '000001',@age OUTPUT
-- PRINT @age


go

