-- SELECT Cname,Cno
-- from course
-- WHERE Ccredit=4

-- SELECT Sname,Sno
-- from student
-- WHERE Sage BETWEEN 20 AND 23

-- SELECT Cno
-- FROM course
-- WHERE Cno NOT in 
-- (
--     SELECT Cno
--     FROM sc
--     WHERE Sno=202131402
-- )

-- SELECT *
-- FROM student
-- WHERE Sname LIKE '刘%'

-- SELECT student.*,Cno,Gread
-- FROM student,sc
-- WHERE student.Sno=sc.Sno

-- SELECT student.*,Cno,Gread
-- FROM student left JOIN sc ON(student.Sno=sc.Sno);
 
--  SELECT Sname,Cname,Gread
--  FROM student,course,sc
--  WHERE student.Sno=sc.Sno AND sc.Cno=course.Cno AND Gread IS NULL
 
-- SELECT COUNT(distinct cno)
-- FROM sc

-- SELECT Sno,Sname
-- FROM student
-- WHERE Sno IN 
-- (
--     SELECT sc.Sno
--     FROM sc,student
--     WHERE sc.Sno=student.Sno
--     GROUP BY sc.Sno
--     HAVING  COUNT(cno)>=3
-- )

-- SELECT AVG(Sage) as avg_age
-- FROM student,sc,course
-- WHERE student.Sno=sc.Sno AND sc.Cno=course.Cno AND Cname='数据库原理'

CREATE VIEW CS_S(sno,sname,Cname,Gread)
AS 
    SELECT student.sno,sname,Cname,gread
    FROM student,course,sc
    WHERE student.Sno=sc.Sno AND sc.Cno=course.Cno AND Sdept='计算机'
go

