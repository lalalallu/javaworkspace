CREATE TRIGGER class_update_cpno
ON class
FOR update
AS  
    IF NOT EXISTS(select cno FROM Class WHERE cno in (select cpno from inserted))
    BEGIN 
        RAISERROR('no class!!',16,1)
        ROLLBACK TRANSACTION
        RETURN
    END
RETURN
go

