CREATE TRIGGER stu_user
ON student
FOR insert
AS  
    BEGIN 
        INSERT 
        into stu_users
        VALUES((select no from inserted ),default,default)
    END
RETURN
go

