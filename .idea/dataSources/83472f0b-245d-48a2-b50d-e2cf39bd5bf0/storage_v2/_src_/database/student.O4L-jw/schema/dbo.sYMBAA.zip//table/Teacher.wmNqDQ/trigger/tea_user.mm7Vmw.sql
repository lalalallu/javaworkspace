CREATE TRIGGER tea_user
ON teacher
FOR insert
AS  
    BEGIN 
        INSERT 
        into tea_users
        VALUES((select tno from inserted ),default,default)
    END
RETURN
go

