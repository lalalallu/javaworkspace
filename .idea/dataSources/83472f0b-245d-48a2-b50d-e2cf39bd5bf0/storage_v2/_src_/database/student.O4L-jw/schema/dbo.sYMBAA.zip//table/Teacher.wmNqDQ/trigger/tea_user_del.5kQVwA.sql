CREATE TRIGGER tea_user_del
ON teacher
FOR DELETE
AS  
    BEGIN 
        DELETE 
        FROM tea_users
        WHERE ID=(select tno from deleted)
    END
RETURN
go

