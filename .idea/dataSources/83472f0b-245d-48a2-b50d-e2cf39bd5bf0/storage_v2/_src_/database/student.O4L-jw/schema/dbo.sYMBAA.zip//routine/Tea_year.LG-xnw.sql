CREATE PROC Tea_year @no CHAR(10) ,@cno CHAR(10) ,@out_year INT OUTPUT
AS
    DECLARE @year INT
    SELECT @year =[year]
    FROM Grade
    WHERE no=@no and cno =@cno
    SELECT @out_year=@year
go

