CREATE TRIGGER stu_user_del
ON student
FOR DELETE
AS  
    BEGIN 
        DELETE 
        FROM stu_users
        WHERE ID=(select no from deleted)
    END
RETURN
go

