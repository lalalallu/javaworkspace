CREATE PROC Tea_age @no CHAR(10) ,@age int OUTPUT
AS
    DECLARE @birth INT,@today INT
    SELECT @birth=YEAR(Birthday)
    FROM Teacher
    WHERE tno=@no
    SELECT @today=YEAR(GETDATE())
    SELECT @age=@today-@birth
go

