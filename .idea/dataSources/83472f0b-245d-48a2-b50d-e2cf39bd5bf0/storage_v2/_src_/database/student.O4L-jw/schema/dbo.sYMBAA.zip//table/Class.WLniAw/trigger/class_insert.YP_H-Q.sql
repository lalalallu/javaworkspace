CREATE TRIGGER class_insert
ON class
FOR INSERT
AS  
    IF NOT EXISTS(select tno FROM Teacher WHERE tno in (select tno from inserted))
    BEGIN 
        RAISERROR('no teacher!!',16,1)
        ROLLBACK TRANSACTION
        RETURN
    END
RETURN
go

